WCounter — автономный Android-проект

Что это:
- Android-приложение с HTML WCounter v87 внутри APK.
- Открывается в отдельном окне, без Chrome и адресной строки.
- Не использует Cloudflare и не требует разрешения на интернет.
- WebView DOM Storage включён; localStorage работает на локальном HTTPS-origin WebViewAssetLoader.
- Исходный ключ данных приложения сохранён: brakcounter_v1.

Сборка:
1. Распаковать архив.
2. Открыть папку WCounter_Android_Project в Android Studio.
3. Дождаться синхронизации Gradle (нужен интернет для загрузки Android Gradle Plugin и AndroidX WebKit).
4. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
5. APK будет в app/build/outputs/apk/debug/app-debug.apk.

Важно:
- Это исходный Android-проект, не готовый APK.
- При удалении приложения Android может удалить локальные данные. Перед удалением/переустановкой нужна резервная копия.
- Установка поверх предыдущей версии с тем же applicationId и подписью обычно сохраняет данные.
- Данные PWA из Chrome автоматически в APK не переносятся: у APK отдельное хранилище.
- Встроен HTML v87 без изменения логики приложения; оригинальный WCounter_v87.html не изменён.
