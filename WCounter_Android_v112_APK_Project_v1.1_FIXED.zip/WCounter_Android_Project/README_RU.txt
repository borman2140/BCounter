WCounter Android — версия 1.1 (HTML v112)
Application ID: sk.oleksandr.wcounter
versionCode: 2; versionName: 1.1
minSdk: 23; compileSdk/targetSdk: 36

Встроена стабильная HTML-версия WCounter v112.
Импорт и экспорт JSON используют системные диалоги выбора и сохранения файлов Android.
Workflow GitHub Actions: .github/workflows/build-apk.yml
