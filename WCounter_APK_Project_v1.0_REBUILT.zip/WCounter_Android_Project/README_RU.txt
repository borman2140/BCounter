WCounter Android APK — версия 1.0
================================

В проект встроен стабильный интерфейс WCounter v109.
Иконка Android заменена на оригинальную PWA-иконку с зелёной буквой W.

Сборка через GitHub Actions:
1. Распакуйте архив.
2. Загрузите содержимое папки WCounter_Android_Project в GitHub-репозиторий.
3. Откройте вкладку Actions.
4. Выберите workflow "Build WCounter APK".
5. Нажмите Run workflow.
6. После успешной сборки откройте запуск и скачайте artifact "WCounter-APK".
7. Внутри artifact будет app-debug.apk.

Параметры:
- Application ID: sk.oleksandr.wcounter
- versionCode: 1
- versionName: 1.0
- minSdk: 23 (Android 6.0+)
- WebView с локальными assets через WebViewAssetLoader
- Интернет-разрешение не требуется
- Данные приложения хранятся локально в WebView

Важно:
Для обновления уже установленного APK используйте тот же GitHub-проект,
тот же applicationId и совместимую подпись APK. Не удаляйте старое приложение,
если хотите сохранить его локальные данные.
